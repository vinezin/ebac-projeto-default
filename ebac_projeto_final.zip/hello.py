print("Olá, vinezin! 👋")
print("Projeto EBAC M16 - /content/da-ebac/")
print("Usuário:", os.environ.get("EBAC_USER", "Não configurado"))
print("✅ Análise de dados funcionando!")

# Teste
import os
print(f"Diretório atual: {os.getcwd()}")
