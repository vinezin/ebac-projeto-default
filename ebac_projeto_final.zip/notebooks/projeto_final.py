
import pandas as pd
print("✅ Dataset:", pd.read_csv("dados/credito.csv").shape)
print("📊 Projeto EBAC executado!")
