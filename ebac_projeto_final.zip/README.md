# 🚀 Projeto Parceria EBAC - Análise Crédito

## 🎯 Problemática
Prever inadimplência cartões BR (R$40bi perdas/ano). Dataset real 20k registros.

## 📊 Coleta
`dados/credito.csv` (879kB) baixado via wget/curl.

## 🔬 Modelagem
- **K-Means**: 3 clusters risco (baixo/médio/alto)
- **Regressão Linear**: R² >0.85
- Insights: Cluster alto = 45% calote, R$2k renda

## 📈 Impacto
-25% perdas com priorização cobrança.

## 💻 Execução
